import axios from "axios";


const createAdmin = async (formData) => {
    try {
        const response = await axios.post(`https://installer-backend.vercel.app/api/admins/`, formData);
        console.log(response)
    }
    catch (error) {
        console.log(error);

    }
}

const getAdminData = async () => {
    try {
        const response = await axios.get(`https://installer-backend.vercel.app/api/admins/`);
        return response;
    } catch (error) {
        console.log(error);
    }
}


const deleteAdmin = async (id) => {
    try {
        const response = await axios.delete(`https://installer-backend.vercel.app/api/admins/${id}`);
        return response;
    } catch (error) {
        console.log(error);
    }
}




const updateAdmin = async (id, dataObject) => {
    try {



        const dataToBePushed = {
            id: dataObject._id,
            name: dataObject.name,
            email: dataObject.email,
            phoneNumber: dataObject.phoneNumber,
            address: dataObject.address,
            password: dataObject.password,
            roles:dataObject.roles

        };


        const response = await axios.put(`https://installer-backend.vercel.app/api/admins/${id}`, dataToBePushed);
        console.log(response)
        return response;
    } catch (error) {
        console.log(error);
    }
}


export {updateAdmin,deleteAdmin,createAdmin,getAdminData}