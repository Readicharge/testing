import { useState } from "react";
import Banner from "./components/Banner";
import NFt2 from "assets/img/nfts/Nft2.png"; // KEEP THIS IMPORT
import NFt4 from "assets/img/nfts/Nft4.png"; // KEEP THIS IMPORT
import NFt3 from "assets/img/nfts/Nft3.png";
import NFt5 from "assets/img/nfts/Nft5.png"; // KEEP THIS IMPORT
import NFt6 from "assets/img/nfts/Nft6.png"; // KEEP THIS IMPORT
import avatar1 from "assets/img/avatars/avatar1.png"; // Will Replace this With the Avator for the Categories
import avatar2 from "assets/img/avatars/avatar2.png"; // Will Replace this With the Avator for the Categories
import avatar3 from "assets/img/avatars/avatar3.png"; // Will Replace this With the Avator for the Categories


// Data Import Section -> To Be Replaced with the API Call
import tableDataTopCreators from "views/admin/marketplace/variables/tableDataTopCreators.json";
import { tableColumnsTopCreators } from "views/admin/marketplace/variables/tableColumnsTopCreators";

// Components Used in the Applicaiton
import HistoryCard from "./components/HistoryCard";
import TopCreatorTable from "./components/TableTopCreators";
import NftCard from "components/card/NftCard";
import ServiceProfile from "./components/HistoryCard";
import ServiceCreate from "./components/TableTopCreators";

console.log()


// Base Component of this file
const Customer = () => {
  const [selectedNft, setSelectedNft] = useState({
    image: null,
    serviceName: " ",
    serviceCode: " ",
    servicePrice: 0.0,
    category: " ",
  }); // For Selected Service preview

  // Callback function to update selectedNft
  const handleNftCardClick = (data) => {
      console.log(data)
      const selectedHistoryData = {
        image: data.image,
        serviceName: data.title,
        serviceCode: "SC-001",
        servicePrice: data.price,
        category: data.author,
        
      }
      
      setSelectedNft(selectedHistoryData);
  };



  return (
    <div className="mt-3 grid h-full grid-cols-1 gap-5 xl:grid-cols-2 2xl:grid-cols-3">
      <div className="col-span-1 h-fit w-full xl:col-span-1 2xl:col-span-2">
        {/* NFt Banner */}
        {/* This will Have the Dynamic Data as per the service */}
        <Banner />

        {/* NFt Header */}
        <div className="mb-4 mt-5 flex flex-col justify-between px-4 md:flex-row md:items-center">
          <h4 className="ml-1 text-2xl font-bold text-navy-700 dark:text-white">
            Service List
          </h4>
        
        </div>

        {/* Service card */}
        <div className="z-20 grid grid-cols-1 p-4 gap-5 md:grid-cols-3" style={{ maxHeight: '100vh', overflowY: 'auto' }}>
          {services.map((service, index) => (
            <NftCard
              key={index}
              bidders={service.bidders}
              title={service.title}
              author={service.author}
              price={service.price}
              image={service.image}
              onCardClick={() => handleNftCardClick(service)}
            />
          ))}
        </div>
      </div>

      {/* right side section */}

      <div className="col-span-1 h-full w-[24vw] right-10 rounded-xl 2xl:col-span-1 fixed">
      <ServiceCreate data={selectedNft} />
      <h4 className="ml-1  mt-4 text-center text-2xl font-bold text-navy-700 dark:text-white">
         Details
          </h4>
        <ServiceProfile data={selectedNft} />
      </div>
    </div>
  );
};

export default Customer;



{/* <TopCreatorTable
extra="mb-5"
tableData={tableDataTopCreators}
columnsData={tableColumnsTopCreators}
/> */}















// Sample data section 
const services = [
  {
    bidders: [avatar1, avatar2, avatar3],
    title: "Abstract Colors",
    author: "Category 1", // Category
    price: "0.91",
    image: NFt3,
  },
  {
    bidders: [avatar1, avatar2, avatar3],
    title: "ETH AI Brain",
    author: "Nick Wilson",
    price: "0.7",
    image: NFt2,
  },
  {
    bidders: [avatar1, avatar2, avatar3],
    title: "Mesh Gradients",
    author: "Will Smith",
    price: "2.91",
    image: NFt4,
  },
  {
    bidders: [avatar1, avatar2, avatar3],
    title: "Digital Artwork",
    author: "Alice Johnson",
    price: "1.25",
    image: NFt3,
  },
  {
    bidders: [avatar1, avatar2, avatar3],
    title: "Abstract Painting",
    author: "Michael Brown",
    price: "0.99",
    image: NFt3,
  },
  {
    bidders: [avatar1, avatar2, avatar3],
    title: "AI Landscape",
    author: "Emma Davis",
    price: "1.75",
    image: NFt4,
  },
  {
    bidders: [avatar1, avatar2, avatar3],
    title: "Crypto Art",
    author: "John Doe",
    price: "3.0",
    image: NFt3,
  },
  {
    bidders: [avatar1, avatar2, avatar3],
    title: "Digital Sculpture",
    author: "Sarah White",
    price: "2.49",
    image: NFt3,
  },
  {
    bidders: [avatar1, avatar2, avatar3],
    title: "Abstract Photography",
    author: "David Lee",
    price: "1.15",
    image: NFt5,
  },
  {
    bidders: [avatar1, avatar2, avatar3],
    title: "Blockchain Art",
    author: "Sophia Adams",
    price: "4.5",
    image: NFt3,
  },
  // Add more services here as needed
];


// Replace avatar1, avatar2, avatar3, NFt2, NFt3, and NFt4 with your actual data.

