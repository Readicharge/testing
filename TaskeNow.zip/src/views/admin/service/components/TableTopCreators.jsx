import React, { useState } from "react";
import { FaDollarSign } from "react-icons/fa";
import Card from "components/card";
import NFt4 from "assets/img/nfts/Nft4.png"; // Import your service image
// Import other necessary assets and components as needed

const ServiceCreate = () => {
  const [serviceData, setServiceData] = useState({
    serviceName: "",
    serviceCode: "sc-001",
    servicePrice: 0.0,
    category: "",
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setServiceData({
      ...serviceData,
      [name]: value,
    });
  };

  const handleCreateClick = () => {
    // Handle the service creation logic here
    // You can submit the data to your backend or perform any other actions
    console.log("Service created:", serviceData);
  };

  return (
    <Card extra={"mt-3 !z-5 overflow-hidden"}>
      <div className="p-4 ">
        <div className="mt-4">
          <div className="mb-4">
            <label
              className="text-sm text-navy-700 dark:text-white block"
              htmlFor="serviceName"
            >
              Service Name
            </label>
            <input
              type="text"
              id="serviceName"
              name="serviceName"
              value={serviceData.serviceName}
              onChange={handleInputChange}
              className="w-[60%] text-sm border-b-2 border-gray-300 focus:border-brand-500 focus:outline-none rounded-md px-2 py-1"
            />
          </div>
          <div className="flex">
            <div className="mb-4">
              <label
                className="text-sm text-navy-700 dark:text-white block"
                htmlFor="category"
              >
                Category
              </label>
              <select
                id="category"
                name="category"
                value={serviceData.category}
                onChange={handleInputChange}
                className="w-[60%] text-sm border-b-2 border-gray-300 focus:border-brand-500 focus:outline-none rounded-md px-2 py-1"
              >
                <option value="">Select a category</option>
                <option value="Category A">Category A</option>
                <option value="Category B">Category B</option>
                {/* Add more options as needed */}
              </select>
            </div>
            <div className="mb-4">
              <label
                className="text-sm text-navy-700 dark:text-white block"
                htmlFor="servicePrice"
              >
                Service Price (USD)
              </label>
              <div className="flex">
                <FaDollarSign className="text-2xl mr-2" />
                <input
                  type="number"
                  step="0.01"
                  id="servicePrice"
                  name="servicePrice"
                  value={serviceData.servicePrice}
                  onChange={handleInputChange}
                  className="w-[40%] text-sm border-b-2 border-gray-300 focus:border-brand-500 focus:outline-none rounded-md px-2 py-1"
                />
              </div>
            </div>
          </div>
        </div>
        <button
          className="mt-4 min-w-50 j linear rounded-[12px] bg-lightPrimary px-4 py-2 text-base font-medium text-brand-500 transition duration-200 hover:bg-gray-100 active:bg-gray-200 dark:bg-white/5 dark:text-white dark:hover:bg-white/10 dark:active:bg-white/20"
          onClick={handleCreateClick}
        >
          Create
        </button>
      </div>
    </Card>
  );
};

export default ServiceCreate;
